package com.atividade5.demo.model;

public enum StatusEnum {
    ABERTO,
    ENCERRADO,
    CANCELADO;
}
